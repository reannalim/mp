package pack;

import java.util.ArrayList;

public class Cart {
	private String username;
	private ArrayList<String> pids;
	private ArrayList<String> pnames;
	private ArrayList<Integer> amounts;
	private ArrayList<Double> prices;
	
	public Cart(String username){
		this.username = username;
		this.pids = new ArrayList<String>();
		this.pnames = new ArrayList<String>();
		this.amounts = new ArrayList<Integer>();
		this.prices = new ArrayList<Double>();
	}
	
	public void delete(String pid){
		
	}
	
	public void add(String pid, int amount){
		
	}

	public double computeTotal(){
		return 0.0;
	}

}
