package pack;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class Hasher {
	private static String ALGORITHM = "SHA-512";
	public static String hashify(String plainText){
		MessageDigest hashBrown;
		try {
			hashBrown = MessageDigest.getInstance(ALGORITHM);
			hashBrown.reset();
			hashBrown.update(plainText.getBytes());
			return Base64.getEncoder().encodeToString(hashBrown.digest());
		} catch (NoSuchAlgorithmException e) {
			return "ERROR: Hashing problem";
		}
	}
}
