package pack;

import java.util.ArrayList;

public class Cart {
	private ArrayList<Integer> ids;
	private ArrayList<String> names;
	private ArrayList<Integer> amounts;
	private ArrayList<Double> prices;
	
	public Cart(){
		clear();
	}
	
	public void clear(){
		this.ids = new ArrayList<Integer>();
		this.names = new ArrayList<String>();
		this.amounts = new ArrayList<Integer>();
		this.prices = new ArrayList<Double>();
	}
	
	public ArrayList<Integer> getIds(){
		return this.ids;
	}

	public ArrayList<String> getNames(){
		return this.names;
	}
	
	public ArrayList<Integer> getAmounts(){
		return this.amounts;
	}
	
	public ArrayList<Double> getPrices(){
		return this.prices;
	}
	
	public void addItem(int id, String name, int amount, double price){
		this.ids.add(id);
		this.names.add(name);
		this.amounts.add(amount);
		this.prices.add(price);
	}

	public double computeTotal(){
		double ret = 0.0;
		for(int i=0; i<this.prices.size(); i++){
			ret += this.prices.get(i)*this.amounts.get(i);
		}
		return ret;
	}
}
